﻿#include "EPD_Test.h"   //Examples

int main(void)
{
    
    //OLED
    // OLED_1in3_C_test();
    
    
    //LCD
    LCD_1in14_test();
    
    
    return 0;
}
